<?php
$method = 'Connection Succes!';
echo $method;
